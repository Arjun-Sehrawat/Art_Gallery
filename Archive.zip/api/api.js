'strict mode';

module.exports = {
    default: "local",
    artic: require("./artic"),
    local: require("./local")
};